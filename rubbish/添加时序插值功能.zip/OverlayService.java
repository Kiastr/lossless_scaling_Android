package com.anime4k.screen;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import android.opengl.GLES20;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.PopupMenu;

import java.nio.ByteBuffer;

public class OverlayService extends Service {

    private static final String TAG = "OverlayService";
    private static final String CHANNEL_ID = "anime4k_channel";
    private static final int NOTIFICATION_ID = 1;

    private WindowManager windowManager;
    private SurfaceView overlaySurfaceView;
    private WindowManager.LayoutParams overlayParams;

    // Floating control button
    private View floatButton;
    private WindowManager.LayoutParams floatButtonParams;
    private boolean floatButtonVisible = true;

    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;

    private HandlerThread processingThread;
    private Handler processingHandler;
    private Handler mainHandler;

    private Anime4KRenderer renderer;

    private int screenWidth, screenHeight, screenDensity;
    private int captureWidth, captureHeight;
    private float captureScale = 0.5f;
    private float refineStrength = 0.5f;
    private float overlayOpacity = 1.0f;

    private boolean isRunning = false;
    private boolean isPaused = false;
    private int frameCount = 0;
    private long fpsStartTime = 0;

    // EGL context for offscreen rendering
    private EGLDisplay eglDisplay;
    private EGLContext eglContext;
    private EGLSurface eglSurface;
    private EGLSurface eglOverlaySurface;

    private boolean surfaceReady = false;
    private Surface overlayOutputSurface;

    // Broadcast receiver for opacity and float button toggle
    private BroadcastReceiver serviceReceiver;

    // Store projection data for recreation on rotation
    private int projectionResultCode;
    private Intent projectionData;

    // Configuration change callback for screen rotation
    private ComponentCallbacks configCallback;
    private int lastOrientation;

    // --- Temporal Interpolation Fields ---
    private int texPrev = 0;
    private int texCurr = 0;
    private long timePrev = 0;
    private long timeCurr = 0;
    private boolean interpolationEnabled = true; // Enabled by default
    private Choreographer choreographer;
    private Choreographer.FrameCallback frameCallback;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        mainHandler = new Handler(Looper.getMainLooper());

        updateScreenMetrics();
        lastOrientation = getResources().getConfiguration().orientation;

        createNotificationChannel();
        registerServiceReceiver();
        registerConfigCallback();
    }

    private void updateScreenMetrics() {
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getRealMetrics(metrics);
        screenWidth = metrics.widthPixels;
        screenHeight = metrics.heightPixels;
        screenDensity = metrics.densityDpi;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;

        String action = intent.getAction();
        if ("STOP".equals(action)) {
            stopSelf();
            return START_NOT_STICKY;
        }

        if ("START".equals(action)) {
            projectionResultCode = intent.getIntExtra("resultCode", 0);
            projectionData = intent.getParcelableExtra("data");
            captureScale = intent.getIntExtra("scale", 50) / 100.0f;
            refineStrength = intent.getIntExtra("strength", 50) / 100.0f;
            overlayOpacity = intent.getIntExtra("opacity", 100) / 100.0f;
            floatButtonVisible = intent.getBooleanExtra("floatButton", true);
            interpolationEnabled = intent.getBooleanExtra("interpolation", true);

            captureWidth = (int) (screenWidth * captureScale);
            captureHeight = (int) (screenHeight * captureScale);
            captureWidth = (captureWidth / 2) * 2;
            captureHeight = (captureHeight / 2) * 2;

            startForeground(NOTIFICATION_ID, createNotification());
            startOverlay();
            if (floatButtonVisible) {
                createFloatButton();
            }
            startCapture(projectionResultCode, projectionData);
        }

        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // ==================== Broadcast Receiver ====================

    private void registerServiceReceiver() {
        serviceReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if ("com.anime4k.screen.UPDATE_OPACITY".equals(action)) {
                    int opacityInt = intent.getIntExtra("opacity", 100);
                    overlayOpacity = opacityInt / 100.0f;
                    applyOverlayOpacity();
                } else if ("com.anime4k.screen.TOGGLE_FLOAT_BUTTON".equals(action)) {
                    boolean show = intent.getBooleanExtra("show", true);
                    toggleFloatButtonVisibility(show);
                } else if ("com.anime4k.screen.TOGGLE_INTERPOLATION".equals(action)) {
                    interpolationEnabled = intent.getBooleanExtra("enabled", true);
                    Log.d(TAG, "Interpolation enabled: " + interpolationEnabled);
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction("com.anime4k.screen.UPDATE_OPACITY");
        filter.addAction("com.anime4k.screen.TOGGLE_FLOAT_BUTTON");
        filter.addAction("com.anime4k.screen.TOGGLE_INTERPOLATION");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(serviceReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(serviceReceiver, filter);
        }
    }

    private void applyOverlayOpacity() {
        if (overlaySurfaceView != null && overlayParams != null && !isPaused) {
            mainHandler.post(() -> {
                try {
                    overlayParams.alpha = overlayOpacity;
                    windowManager.updateViewLayout(overlaySurfaceView, overlayParams);
                } catch (Exception e) {
                    Log.e(TAG, "Error updating overlay opacity", e);
                }
            });
        }
    }

    // ==================== Configuration Change (Rotation) ====================

    private void registerConfigCallback() {
        configCallback = new ComponentCallbacks() {
            @Override
            public void onConfigurationChanged(Configuration newConfig) {
                int newOrientation = newConfig.orientation;
                if (newOrientation != lastOrientation) {
                    lastOrientation = newOrientation;
                    Log.d(TAG, "Orientation changed to: " + (newOrientation == Configuration.ORIENTATION_LANDSCAPE ? "landscape" : "portrait"));
                    mainHandler.postDelayed(() -> handleOrientationChange(), 300);
                }
            }

            @Override
            public void onLowMemory() {}
        };
        registerComponentCallbacks(configCallback);
    }

    private void handleOrientationChange() {
        if (!isRunning) return;

        int oldWidth = screenWidth;
        int oldHeight = screenHeight;
        updateScreenMetrics();

        if (screenWidth == oldWidth && screenHeight == oldHeight) {
            return;
        }

        Log.d(TAG, "Screen size changed: " + oldWidth + "x" + oldHeight + " -> " + screenWidth + "x" + screenHeight);

        captureWidth = (int) (screenWidth * captureScale);
        captureHeight = (int) (screenHeight * captureScale);
        captureWidth = (captureWidth / 2) * 2;
        captureHeight = (captureHeight / 2) * 2;

        processingHandler.post(() -> {
            try {
                if (virtualDisplay != null) {
                    virtualDisplay.release();
                    virtualDisplay = null;
                }
                if (imageReader != null) {
                    imageReader.close();
                    imageReader = null;
                }

                if (eglOverlaySurface != null && eglOverlaySurface != EGL14.EGL_NO_SURFACE) {
                    EGL14.eglDestroySurface(eglDisplay, eglOverlaySurface);
                    eglOverlaySurface = null;
                }

                makePbufferCurrent();
                if (renderer != null) {
                    renderer.init(captureWidth, captureHeight, screenWidth, screenHeight);
                }

                imageReader = ImageReader.newInstance(captureWidth, captureHeight,
                        PixelFormat.RGBA_8888, 4);

                virtualDisplay = mediaProjection.createVirtualDisplay(
                        "Anime4KCapture",
                        captureWidth, captureHeight, screenDensity,
                        DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                        imageReader.getSurface(),
                        null, processingHandler
                );
                Log.d(TAG, "Capture pipeline rebuilt: " + captureWidth + "x" + captureHeight + " -> " + screenWidth + "x" + screenHeight);

            } catch (Exception e) {
                Log.e(TAG, "Error handling orientation change", e);
            }
        });
    }

    // ==================== Floating Control Button ====================

    private void createFloatButton() {
        ImageView button = new ImageView(this);
        button.setImageResource(android.R.drawable.ic_media_pause);
        button.setColorFilter(Color.WHITE);
        button.setBackgroundColor(0xCC03DAC5);
        button.setPadding(12, 12, 12, 12);
        button.setScaleType(ImageView.ScaleType.CENTER_INSIDE);

        floatButton = button;

        int overlayType;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            overlayType = WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY;
        }

        int buttonSize = (int) (48 * getResources().getDisplayMetrics().density);

        floatButtonParams = new WindowManager.LayoutParams(
                buttonSize,
                buttonSize,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        floatButtonParams.gravity = Gravity.TOP | Gravity.START;
        floatButtonParams.x = screenWidth - buttonSize - 16;
        floatButtonParams.y = screenHeight / 2;
        floatButtonParams.alpha = 0.8f;

        button.setOnTouchListener(new FloatButtonTouchListener());

        windowManager.addView(floatButton, floatButtonParams);
        updateFloatButtonState();
    }

    private void toggleFloatButtonVisibility(boolean show) {
        floatButtonVisible = show;
        mainHandler.post(() -> {
            if (show && floatButton == null) {
                createFloatButton();
            } else if (!show && floatButton != null) {
                try {
                    windowManager.removeView(floatButton);
                } catch (Exception e) {
                    Log.e(TAG, "Error removing float button", e);
                }
                floatButton = null;
            }
        });
    }

    private void updateFloatButtonState() {
        if (floatButton == null) return;
        mainHandler.post(() -> {
            ImageView btn = (ImageView) floatButton;
            if (isPaused) {
                btn.setImageResource(android.R.drawable.ic_media_play);
                btn.setBackgroundColor(0xCC888888);
            } else {
                btn.setImageResource(android.R.drawable.ic_media_pause);
                btn.setBackgroundColor(0xCC03DAC5);
            }
        });
    }

    private void togglePause() {
        isPaused = !isPaused;
        updateFloatButtonState();
        if (isPaused) {
            mainHandler.post(() -> {
                if (overlayParams != null && overlaySurfaceView != null) {
                    overlayParams.alpha = 0f;
                    try {
                        windowManager.updateViewLayout(overlaySurfaceView, overlayParams);
                    } catch (Exception e) {
                        Log.e(TAG, "Error hiding overlay", e);
                    }
                }
            });
        } else {
            mainHandler.post(() -> {
                if (overlayParams != null && overlaySurfaceView != null) {
                    overlayParams.alpha = overlayOpacity;
                    try {
                        windowManager.updateViewLayout(overlaySurfaceView, overlayParams);
                    } catch (Exception e) {
                        Log.e(TAG, "Error showing overlay", e);
                    }
                }
            });
        }
    }

    private void showFloatButtonMenu() {
        mainHandler.post(() -> {
            try {
                PopupMenu popup = new PopupMenu(this, floatButton);
                popup.getMenu().add(0, 1, 0, "停止服务");
                popup.getMenu().add(0, 2, 1, "返回主界面");
                popup.setOnMenuItemClickListener(item -> {
                    switch (item.getItemId()) {
                        case 1:
                            stopSelf();
                            return true;
                        case 2:
                            Intent mainIntent = new Intent(this, MainActivity.class);
                            mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                    | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                            startActivity(mainIntent);
                            return true;
                    }
                    return false;
                });
                popup.show();
            } catch (Exception e) {
                Log.e(TAG, "Error showing popup menu", e);
            }
        });
    }

    private class FloatButtonTouchListener implements View.OnTouchListener {
        private int initialX, initialY;
        private float initialTouchX, initialTouchY;
        private boolean isDragging = false;
        private boolean longPressTriggered = false;
        private long touchDownTime;
        private static final int CLICK_THRESHOLD = 10;
        private static final long LONG_PRESS_TIMEOUT = 600;

        private Runnable longPressRunnable = () -> {
            longPressTriggered = true;
            showFloatButtonMenu();
        };

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    initialX = floatButtonParams.x;
                    initialY = floatButtonParams.y;
                    initialTouchX = event.getRawX();
                    initialTouchY = event.getRawY();
                    isDragging = false;
                    longPressTriggered = false;
                    touchDownTime = System.currentTimeMillis();
                    mainHandler.postDelayed(longPressRunnable, LONG_PRESS_TIMEOUT);
                    return true;

                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - initialTouchX;
                    float dy = event.getRawY() - initialTouchY;
                    if (Math.abs(dx) > CLICK_THRESHOLD || Math.abs(dy) > CLICK_THRESHOLD) {
                        isDragging = true;
                        mainHandler.removeCallbacks(longPressRunnable);
                    }
                    if (isDragging) {
                        floatButtonParams.x = initialX + (int) dx;
                        floatButtonParams.y = initialY + (int) dy;
                        try {
                            windowManager.updateViewLayout(floatButton, floatButtonParams);
                        } catch (Exception e) {}
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                    mainHandler.removeCallbacks(longPressRunnable);
                    if (isDragging) {
                        snapToEdge();
                    } else if (!longPressTriggered) {
                        togglePause();
                    }
                    return true;
            }
            return false;
        }
    }

    private void snapToEdge() {
        if (floatButton == null || floatButtonParams == null) return;
        updateScreenMetrics();
        int buttonSize = floatButtonParams.width;
        int centerX = floatButtonParams.x + buttonSize / 2;
        int margin = 8;

        if (centerX < screenWidth / 2) {
            floatButtonParams.x = margin;
        } else {
            floatButtonParams.x = screenWidth - buttonSize - margin;
        }

        floatButtonParams.y = Math.max(0, Math.min(floatButtonParams.y, screenHeight - buttonSize));

        try {
            windowManager.updateViewLayout(floatButton, floatButtonParams);
        } catch (Exception e) {}
    }

    // ==================== Overlay ====================

    private void startOverlay() {
        overlaySurfaceView = new SurfaceView(this);

        int overlayType;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            overlayType = WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY;
        }

        overlayParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
        );
        overlayParams.gravity = Gravity.TOP | Gravity.START;
        overlayParams.x = 0;
        overlayParams.y = 0;
        overlayParams.alpha = overlayOpacity;

        overlaySurfaceView.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                Log.d(TAG, "Overlay surface created");
                overlayOutputSurface = holder.getSurface();
                surfaceReady = true;
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
                if (processingHandler != null) {
                    processingHandler.post(() -> {
                        if (eglOverlaySurface != null && eglOverlaySurface != EGL14.EGL_NO_SURFACE) {
                            EGL14.eglDestroySurface(eglDisplay, eglOverlaySurface);
                            eglOverlaySurface = null;
                        }
                    });
                }
            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                surfaceReady = false;
                overlayOutputSurface = null;
            }
        });

        overlaySurfaceView.setZOrderOnTop(true);
        overlaySurfaceView.getHolder().setFormat(PixelFormat.TRANSLUCENT);

        windowManager.addView(overlaySurfaceView, overlayParams);
    }

    // ==================== Capture & Processing ====================

    private void startCapture(int resultCode, Intent data) {
        processingThread = new HandlerThread("Anime4K-Processing");
        processingThread.start();
        processingHandler = new Handler(processingThread.getLooper());

        MediaProjectionManager projectionManager =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        mediaProjection = projectionManager.getMediaProjection(resultCode, data);

        mediaProjection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                stopSelf();
            }
        }, processingHandler);

        imageReader = ImageReader.newInstance(captureWidth, captureHeight,
                PixelFormat.RGBA_8888, 4);

        virtualDisplay = mediaProjection.createVirtualDisplay(
                "Anime4KCapture",
                captureWidth, captureHeight, screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(),
                null, processingHandler
        );

        processingHandler.post(() -> {
            initEGL();
            renderer = new Anime4KRenderer();
            renderer.setRefineStrength(refineStrength);
            renderer.init(captureWidth, captureHeight, screenWidth, screenHeight);
            isRunning = true;
            fpsStartTime = System.currentTimeMillis();
            
            // Start the capture loop
            processingHandler.post(this::captureLoop);
            
            // Start the display sync loop on main thread
            mainHandler.post(() -> {
                choreographer = Choreographer.getInstance();
                frameCallback = new Choreographer.FrameCallback() {
                    @Override
                    public void doFrame(long frameTimeNanos) {
                        if (isRunning && !isPaused && surfaceReady) {
                            processingHandler.post(() -> renderLoop(frameTimeNanos));
                        }
                        if (isRunning) {
                            choreographer.postFrameCallback(this);
                        }
                    }
                };
                choreographer.postFrameCallback(frameCallback);
            });
        });
    }

    /**
     * Capture loop: continuously acquire latest frames from ImageReader.
     */
    private void captureLoop() {
        if (!isRunning) return;
        
        Image image = null;
        try {
            image = imageReader.acquireLatestImage();
            if (image != null) {
                long timestamp = image.getTimestamp() / 1000000; // ns to ms
                
                // Convert Image to Bitmap
                Image.Plane[] planes = image.getPlanes();
                ByteBuffer buffer = planes[0].getBuffer();
                int pixelStride = planes[0].getPixelStride();
                int rowStride = planes[0].getRowStride();
                int rowPadding = rowStride - pixelStride * captureWidth;

                Bitmap bitmap = Bitmap.createBitmap(
                        captureWidth + rowPadding / pixelStride,
                        captureHeight,
                        Bitmap.Config.ARGB_8888);
                bitmap.copyPixelsFromBuffer(buffer);

                if (bitmap.getWidth() != captureWidth) {
                    Bitmap cropped = Bitmap.createBitmap(bitmap, 0, 0, captureWidth, captureHeight);
                    bitmap.recycle();
                    bitmap = cropped;
                }

                image.close();
                image = null;

                makePbufferCurrent();
                int newTex = renderer.process(bitmap);
                bitmap.recycle();

                // Update frame buffer
                if (texPrev != 0) {
                    GLES20.glDeleteTextures(1, new int[]{texPrev}, 0);
                }
                texPrev = texCurr;
                timePrev = timeCurr;
                
                texCurr = renderer.copyTexture(newTex);
                timeCurr = timestamp;
                
                if (timePrev == 0) timePrev = timeCurr - 33; // Assume 30fps if first frame
            }
        } catch (Exception e) {
            Log.e(TAG, "Error in capture loop", e);
            if (image != null) image.close();
        }

        if (isRunning) {
            processingHandler.postDelayed(this::captureLoop, 5); // Small delay to not hog CPU
        }
    }

    /**
     * Render loop: triggered by Choreographer (VSYNC).
     */
    private void renderLoop(long frameTimeNanos) {
        if (!isRunning || isPaused || !surfaceReady || texCurr == 0) return;

        try {
            makePbufferCurrent();
            
            long displayTimeMs = frameTimeNanos / 1000000;
            
            // Calculate interpolation factor (mix)
            float mix = 1.0f;
            if (interpolationEnabled && texPrev != 0 && timeCurr > timePrev) {
                // mpv-like oversample: mix = (display_time - frame_time) / frame_duration
                long duration = timeCurr - timePrev;
                mix = (float)(displayTimeMs - timeCurr) / duration;
                mix = Math.max(0.0f, Math.min(1.0f, mix + 1.0f)); // Simple linear blend
            }

            if (overlayOutputSurface != null && surfaceReady) {
                renderToOverlay(texPrev, texCurr, mix);
            }

            // FPS counting
            frameCount++;
            long now = System.currentTimeMillis();
            if (now - fpsStartTime >= 1000) {
                float fps = frameCount * 1000.0f / (now - fpsStartTime);
                frameCount = 0;
                fpsStartTime = now;

                Intent fpsIntent = new Intent("com.anime4k.screen.FPS_UPDATE");
                fpsIntent.putExtra("fps", fps);
                fpsIntent.setPackage(getPackageName());
                sendBroadcast(fpsIntent);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error in render loop", e);
        }
    }

    private void renderToOverlay(int tPrev, int tCurr, float mix) {
        try {
            if (eglOverlaySurface == null || eglOverlaySurface == EGL14.EGL_NO_SURFACE) {
                if (overlayOutputSurface != null) {
                    int[] surfaceAttribs = { EGL14.EGL_NONE };
                    eglOverlaySurface = EGL14.eglCreateWindowSurface(
                            eglDisplay, getEGLConfig(), overlayOutputSurface, surfaceAttribs, 0);
                }
            }

            if (eglOverlaySurface == null || eglOverlaySurface == EGL14.EGL_NO_SURFACE) return;

            EGL14.eglMakeCurrent(eglDisplay, eglOverlaySurface, eglOverlaySurface, eglContext);

            if (interpolationEnabled && tPrev != 0) {
                renderer.renderInterpolatedToScreen(tPrev, tCurr, mix, screenWidth, screenHeight);
            } else {
                renderer.renderToScreen(tCurr, screenWidth, screenHeight);
            }

            EGL14.eglSwapBuffers(eglDisplay, eglOverlaySurface);
            makePbufferCurrent();
        } catch (Exception e) {
            Log.e(TAG, "Error rendering to overlay", e);
            if (eglOverlaySurface != null && eglOverlaySurface != EGL14.EGL_NO_SURFACE) {
                EGL14.eglDestroySurface(eglDisplay, eglOverlaySurface);
                eglOverlaySurface = null;
            }
        }
    }

    private void initEGL() {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
        int[] version = new int[2];
        EGL14.eglInitialize(eglDisplay, version, 0, version, 1);

        EGLConfig config = getEGLConfig();
        int[] contextAttribs = { EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE };
        eglContext = EGL14.eglCreateContext(eglDisplay, config, EGL14.EGL_NO_CONTEXT, contextAttribs, 0);

        int[] pbufferAttribs = { EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE };
        eglSurface = EGL14.eglCreatePbufferSurface(eglDisplay, config, pbufferAttribs, 0);
        makePbufferCurrent();
    }

    private void makePbufferCurrent() {
        EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext);
    }

    private EGLConfig getEGLConfig() {
        int[] configAttribs = {
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT | EGL14.EGL_PBUFFER_BIT,
            EGL14.EGL_NONE
        };
        EGLConfig[] configs = new EGLConfig[1];
        int[] numConfigs = new int[1];
        EGL14.eglChooseConfig(eglDisplay, configAttribs, 0, configs, 0, 1, numConfigs, 0);
        return configs[0];
    }

    @Override
    public void onDestroy() {
        isRunning = false;
        if (processingThread != null) {
            processingThread.quitSafely();
        }
        if (virtualDisplay != null) virtualDisplay.release();
        if (mediaProjection != null) mediaProjection.stop();
        if (imageReader != null) imageReader.close();
        
        unregisterReceiver(serviceReceiver);
        unregisterComponentCallbacks(configCallback);
        
        if (floatButton != null) windowManager.removeView(floatButton);
        if (overlaySurfaceView != null) windowManager.removeView(overlaySurfaceView);
        
        processingHandler.post(() -> {
            if (renderer != null) renderer.release();
            if (texPrev != 0) GLES20.glDeleteTextures(1, new int[]{texPrev}, 0);
            if (texCurr != 0) GLES20.glDeleteTextures(1, new int[]{texCurr}, 0);
            releaseEGL();
        });
        
        super.onDestroy();
    }

    private void releaseEGL() {
        if (eglDisplay != null) {
            if (eglOverlaySurface != null) EGL14.eglDestroySurface(eglDisplay, eglOverlaySurface);
            if (eglSurface != null) EGL14.eglDestroySurface(eglDisplay, eglSurface);
            if (eglContext != null) EGL14.eglDestroyContext(eglDisplay, eglContext);
            EGL14.eglTerminate(eglDisplay);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Anime4K Screen Service", NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private Notification createNotification() {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ? 
            new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return builder.setContentTitle("Anime4K 屏幕超分中").setContentText("正在实时增强屏幕画质...").setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(pendingIntent).build();
    }
}
