package com.anime4k.screen;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.PopupMenu;

import java.nio.ByteBuffer;

public class OverlayService extends Service {

    private static final String TAG = "OverlayService";
    private static final String CHANNEL_ID = "anime4k_channel";
    private static final int NOTIFICATION_ID = 1;

    private WindowManager windowManager;
    private SurfaceView overlaySurfaceView;
    private WindowManager.LayoutParams overlayParams;

    // Floating control button
    private View floatButton;
    private WindowManager.LayoutParams floatButtonParams;
    private boolean floatButtonVisible = true;

    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;

    private HandlerThread processingThread;
    private Handler processingHandler;
    private Handler mainHandler;

    private Anime4KRenderer renderer;

    private int screenWidth, screenHeight, screenDensity;
    private int captureWidth, captureHeight;
    private float captureScale = 0.5f;
    private float refineStrength = 0.5f;
    private float overlayOpacity = 1.0f;

    private boolean isRunning = false;
    private boolean isPaused = false;
    private int frameCount = 0;
    private long fpsStartTime = 0;

    // EGL context for offscreen rendering
    private EGLDisplay eglDisplay;
    private EGLContext eglContext;
    private EGLSurface eglSurface;
    private EGLSurface eglOverlaySurface;

    private boolean surfaceReady = false;
    private Surface overlayOutputSurface;

    // Broadcast receiver for opacity and float button toggle
    private BroadcastReceiver serviceReceiver;

    // Store projection data for recreation on rotation
    private int projectionResultCode;
    private Intent projectionData;

    // Configuration change callback for screen rotation
    private ComponentCallbacks configCallback;
    private int lastOrientation;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        mainHandler = new Handler(Looper.getMainLooper());

        updateScreenMetrics();
        lastOrientation = getResources().getConfiguration().orientation;

        createNotificationChannel();
        registerServiceReceiver();
        registerConfigCallback();
    }

    private void updateScreenMetrics() {
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getRealMetrics(metrics);
        screenWidth = metrics.widthPixels;
        screenHeight = metrics.heightPixels;
        screenDensity = metrics.densityDpi;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;

        String action = intent.getAction();
        if ("STOP".equals(action)) {
            stopSelf();
            return START_NOT_STICKY;
        }

        if ("START".equals(action)) {
            projectionResultCode = intent.getIntExtra("resultCode", 0);
            projectionData = intent.getParcelableExtra("data");
            captureScale = intent.getIntExtra("scale", 50) / 100.0f;
            refineStrength = intent.getIntExtra("strength", 50) / 100.0f;
            overlayOpacity = intent.getIntExtra("opacity", 100) / 100.0f;
            floatButtonVisible = intent.getBooleanExtra("floatButton", true);

            captureWidth = (int) (screenWidth * captureScale);
            captureHeight = (int) (screenHeight * captureScale);
            captureWidth = (captureWidth / 2) * 2;
            captureHeight = (captureHeight / 2) * 2;

            startForeground(NOTIFICATION_ID, createNotification());
            startOverlay();
            if (floatButtonVisible) {
                createFloatButton();
            }
            startCapture(projectionResultCode, projectionData);
        }

        return START_NOT_STICKY;
    }

    // ==================== Broadcast Receiver ====================

    private void registerServiceReceiver() {
        serviceReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if ("com.anime4k.screen.UPDATE_OPACITY".equals(action)) {
                    int opacityInt = intent.getIntExtra("opacity", 100);
                    overlayOpacity = opacityInt / 100.0f;
                    applyOverlayOpacity();
                } else if ("com.anime4k.screen.TOGGLE_FLOAT_BUTTON".equals(action)) {
                    boolean show = intent.getBooleanExtra("show", true);
                    toggleFloatButtonVisibility(show);
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction("com.anime4k.screen.UPDATE_OPACITY");
        filter.addAction("com.anime4k.screen.TOGGLE_FLOAT_BUTTON");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(serviceReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(serviceReceiver, filter);
        }
    }

    private void applyOverlayOpacity() {
        if (overlaySurfaceView != null && overlayParams != null && !isPaused) {
            mainHandler.post(() -> {
                try {
                    overlayParams.alpha = overlayOpacity;
                    windowManager.updateViewLayout(overlaySurfaceView, overlayParams);
                } catch (Exception e) {
                    Log.e(TAG, "Error updating overlay opacity", e);
                }
            });
        }
    }

    // ==================== Configuration Change (Rotation) ====================

    private void registerConfigCallback() {
        configCallback = new ComponentCallbacks() {
            @Override
            public void onConfigurationChanged(Configuration newConfig) {
                int newOrientation = newConfig.orientation;
                if (newOrientation != lastOrientation) {
                    lastOrientation = newOrientation;
                    Log.d(TAG, "Orientation changed to: " + (newOrientation == Configuration.ORIENTATION_LANDSCAPE ? "landscape" : "portrait"));
                    // Delay slightly to let the system finish rotation
                    mainHandler.postDelayed(() -> handleOrientationChange(), 300);
                }
            }

            @Override
            public void onLowMemory() {
                // ignore
            }
        };
        registerComponentCallbacks(configCallback);
    }

    private void handleOrientationChange() {
        if (!isRunning) return;

        // Update screen metrics
        int oldWidth = screenWidth;
        int oldHeight = screenHeight;
        updateScreenMetrics();

        if (screenWidth == oldWidth && screenHeight == oldHeight) {
            return; // No actual size change
        }

        Log.d(TAG, "Screen size changed: " + oldWidth + "x" + oldHeight + " -> " + screenWidth + "x" + screenHeight);

        // Recalculate capture dimensions
        captureWidth = (int) (screenWidth * captureScale);
        captureHeight = (int) (screenHeight * captureScale);
        captureWidth = (captureWidth / 2) * 2;
        captureHeight = (captureHeight / 2) * 2;

        // Rebuild the capture pipeline on the processing thread
        processingHandler.post(() -> {
            try {
                // Release old virtual display and image reader
                if (virtualDisplay != null) {
                    virtualDisplay.release();
                    virtualDisplay = null;
                }
                if (imageReader != null) {
                    imageReader.close();
                    imageReader = null;
                }

                // Destroy old EGL overlay surface (will be recreated on next render)
                if (eglOverlaySurface != null && eglOverlaySurface != EGL14.EGL_NO_SURFACE) {
                    EGL14.eglDestroySurface(eglDisplay, eglOverlaySurface);
                    eglOverlaySurface = null;
                }

                // Reinitialize renderer with new dimensions
                makePbufferCurrent();
                if (renderer != null) {
                    renderer.init(captureWidth, captureHeight, screenWidth, screenHeight);
                }

                // Recreate image reader and virtual display
                imageReader = ImageReader.newInstance(captureWidth, captureHeight,
                        PixelFormat.RGBA_8888, 4);

                virtualDisplay = mediaProjection.createVirtualDisplay(
                        "Anime4KCapture",
                        captureWidth, captureHeight, screenDensity,
                        DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                        imageReader.getSurface(),
                        null, processingHandler
                );

                Log.d(TAG, "Capture pipeline rebuilt: " + captureWidth + "x" + captureHeight + " -> " + screenWidth + "x" + screenHeight);

            } catch (Exception e) {
                Log.e(TAG, "Error handling orientation change", e);
            }
        });
    }

    // ==================== Floating Control Button ====================

    private void createFloatButton() {
        ImageView button = new ImageView(this);
        button.setImageResource(android.R.drawable.ic_media_pause);
        button.setColorFilter(Color.WHITE);
        button.setBackgroundColor(0xCC03DAC5);
        button.setPadding(12, 12, 12, 12);
        button.setScaleType(ImageView.ScaleType.CENTER_INSIDE);

        floatButton = button;

        int overlayType;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            overlayType = WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY;
        }

        int buttonSize = (int) (48 * getResources().getDisplayMetrics().density);

        floatButtonParams = new WindowManager.LayoutParams(
                buttonSize,
                buttonSize,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        floatButtonParams.gravity = Gravity.TOP | Gravity.START;
        floatButtonParams.x = screenWidth - buttonSize - 16;
        floatButtonParams.y = screenHeight / 2;
        floatButtonParams.alpha = 0.8f;

        button.setOnTouchListener(new FloatButtonTouchListener());

        windowManager.addView(floatButton, floatButtonParams);
        updateFloatButtonState();
    }

    private void toggleFloatButtonVisibility(boolean show) {
        floatButtonVisible = show;
        mainHandler.post(() -> {
            if (show && floatButton == null) {
                createFloatButton();
            } else if (!show && floatButton != null) {
                try {
                    windowManager.removeView(floatButton);
                } catch (Exception e) {
                    Log.e(TAG, "Error removing float button", e);
                }
                floatButton = null;
            }
        });
    }

    private void updateFloatButtonState() {
        if (floatButton == null) return;
        mainHandler.post(() -> {
            ImageView btn = (ImageView) floatButton;
            if (isPaused) {
                btn.setImageResource(android.R.drawable.ic_media_play);
                btn.setBackgroundColor(0xCC888888);
            } else {
                btn.setImageResource(android.R.drawable.ic_media_pause);
                btn.setBackgroundColor(0xCC03DAC5);
            }
        });
    }

    private void togglePause() {
        isPaused = !isPaused;
        updateFloatButtonState();
        if (isPaused) {
            // Make overlay fully transparent so original screen is visible.
            // We do NOT use setVisibility(GONE) because that destroys the Surface
            // and the EGL window surface, making it impossible to resume rendering.
            mainHandler.post(() -> {
                if (overlayParams != null && overlaySurfaceView != null) {
                    overlayParams.alpha = 0f;
                    try {
                        windowManager.updateViewLayout(overlaySurfaceView, overlayParams);
                    } catch (Exception e) {
                        Log.e(TAG, "Error hiding overlay", e);
                    }
                }
            });
        } else {
            // Restore overlay opacity and resume processing
            mainHandler.post(() -> {
                if (overlayParams != null && overlaySurfaceView != null) {
                    overlayParams.alpha = overlayOpacity;
                    try {
                        windowManager.updateViewLayout(overlaySurfaceView, overlayParams);
                    } catch (Exception e) {
                        Log.e(TAG, "Error showing overlay", e);
                    }
                }
            });
            if (isRunning) {
                processingHandler.post(this::processFrame);
            }
        }
    }

    private void showFloatButtonMenu() {
        mainHandler.post(() -> {
            try {
                PopupMenu popup = new PopupMenu(this, floatButton);
                popup.getMenu().add(0, 1, 0, "停止服务");
                popup.getMenu().add(0, 2, 1, "返回主界面");
                popup.setOnMenuItemClickListener(item -> {
                    switch (item.getItemId()) {
                        case 1:
                            stopSelf();
                            return true;
                        case 2:
                            Intent mainIntent = new Intent(this, MainActivity.class);
                            mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                    | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                            startActivity(mainIntent);
                            return true;
                    }
                    return false;
                });
                popup.show();
            } catch (Exception e) {
                Log.e(TAG, "Error showing popup menu", e);
            }
        });
    }

    /**
     * Touch listener for the floating button.
     * Supports drag, click (toggle pause), and long-press (show menu).
     * On release, the button snaps to the nearest screen edge.
     */
    private class FloatButtonTouchListener implements View.OnTouchListener {
        private int initialX, initialY;
        private float initialTouchX, initialTouchY;
        private boolean isDragging = false;
        private boolean longPressTriggered = false;
        private long touchDownTime;
        private static final int CLICK_THRESHOLD = 10;
        private static final long LONG_PRESS_TIMEOUT = 600;

        private Runnable longPressRunnable = () -> {
            longPressTriggered = true;
            showFloatButtonMenu();
        };

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    initialX = floatButtonParams.x;
                    initialY = floatButtonParams.y;
                    initialTouchX = event.getRawX();
                    initialTouchY = event.getRawY();
                    isDragging = false;
                    longPressTriggered = false;
                    touchDownTime = System.currentTimeMillis();
                    mainHandler.postDelayed(longPressRunnable, LONG_PRESS_TIMEOUT);
                    return true;

                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - initialTouchX;
                    float dy = event.getRawY() - initialTouchY;
                    if (Math.abs(dx) > CLICK_THRESHOLD || Math.abs(dy) > CLICK_THRESHOLD) {
                        isDragging = true;
                        mainHandler.removeCallbacks(longPressRunnable);
                    }
                    if (isDragging) {
                        floatButtonParams.x = initialX + (int) dx;
                        floatButtonParams.y = initialY + (int) dy;
                        try {
                            windowManager.updateViewLayout(floatButton, floatButtonParams);
                        } catch (Exception e) {
                            // view may have been removed
                        }
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                    mainHandler.removeCallbacks(longPressRunnable);
                    if (isDragging) {
                        snapToEdge();
                    } else if (!longPressTriggered) {
                        togglePause();
                    }
                    return true;
            }
            return false;
        }
    }

    private void snapToEdge() {
        if (floatButton == null || floatButtonParams == null) return;
        // Re-read screen size for correct snapping in any orientation
        updateScreenMetrics();
        int buttonSize = floatButtonParams.width;
        int centerX = floatButtonParams.x + buttonSize / 2;
        int margin = 8;

        if (centerX < screenWidth / 2) {
            floatButtonParams.x = margin;
        } else {
            floatButtonParams.x = screenWidth - buttonSize - margin;
        }

        floatButtonParams.y = Math.max(0, Math.min(floatButtonParams.y, screenHeight - buttonSize));

        try {
            windowManager.updateViewLayout(floatButton, floatButtonParams);
        } catch (Exception e) {
            // view may have been removed
        }
    }

    // ==================== Overlay ====================

    private void startOverlay() {
        overlaySurfaceView = new SurfaceView(this);

        int overlayType;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            overlayType = WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY;
        }

        overlayParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
        );
        overlayParams.gravity = Gravity.TOP | Gravity.START;
        overlayParams.x = 0;
        overlayParams.y = 0;
        overlayParams.alpha = overlayOpacity;

        overlaySurfaceView.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                Log.d(TAG, "Overlay surface created");
                overlayOutputSurface = holder.getSurface();
                surfaceReady = true;
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
                Log.d(TAG, "Overlay surface changed: " + width + "x" + height);
                // When surface size changes (e.g. rotation), destroy old EGL surface
                // so it gets recreated with the new size on next render
                if (processingHandler != null) {
                    processingHandler.post(() -> {
                        if (eglOverlaySurface != null && eglOverlaySurface != EGL14.EGL_NO_SURFACE) {
                            EGL14.eglDestroySurface(eglDisplay, eglOverlaySurface);
                            eglOverlaySurface = null;
                        }
                    });
                }
            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                surfaceReady = false;
                overlayOutputSurface = null;
            }
        });

        overlaySurfaceView.setZOrderOnTop(true);
        overlaySurfaceView.getHolder().setFormat(PixelFormat.TRANSLUCENT);

        windowManager.addView(overlaySurfaceView, overlayParams);
    }

    // ==================== Capture & Processing ====================

    private void startCapture(int resultCode, Intent data) {
        processingThread = new HandlerThread("Anime4K-Processing");
        processingThread.start();
        processingHandler = new Handler(processingThread.getLooper());

        MediaProjectionManager projectionManager =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        mediaProjection = projectionManager.getMediaProjection(resultCode, data);

        mediaProjection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                Log.d(TAG, "MediaProjection stopped");
                stopSelf();
            }
        }, processingHandler);

        imageReader = ImageReader.newInstance(captureWidth, captureHeight,
                PixelFormat.RGBA_8888, 4);

        virtualDisplay = mediaProjection.createVirtualDisplay(
                "Anime4KCapture",
                captureWidth, captureHeight, screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(),
                null, processingHandler
        );

        processingHandler.post(() -> {
            initEGL();
            renderer = new Anime4KRenderer();
            renderer.setRefineStrength(refineStrength);
            renderer.init(captureWidth, captureHeight, screenWidth, screenHeight);
            isRunning = true;
            fpsStartTime = System.currentTimeMillis();
            processFrame();
        });
    }

    /**
     * Process frames continuously without delay.
     * Uses acquireLatestImage() to always get the most recent frame, discarding stale ones.
     */
    private void processFrame() {
        if (!isRunning) return;
        if (isPaused) {
            processingHandler.postDelayed(this::processFrame, 100);
            return;
        }
        if (!surfaceReady) {
            processingHandler.postDelayed(this::processFrame, 16);
            return;
        }

        Image image = null;
        try {
            image = imageReader.acquireLatestImage();
            if (image == null) {
                processingHandler.post(this::processFrame);
                return;
            }

            // Convert Image to Bitmap
            Image.Plane[] planes = image.getPlanes();
            ByteBuffer buffer = planes[0].getBuffer();
            int pixelStride = planes[0].getPixelStride();
            int rowStride = planes[0].getRowStride();
            int rowPadding = rowStride - pixelStride * captureWidth;

            Bitmap bitmap = Bitmap.createBitmap(
                    captureWidth + rowPadding / pixelStride,
                    captureHeight,
                    Bitmap.Config.ARGB_8888);
            bitmap.copyPixelsFromBuffer(buffer);

            if (bitmap.getWidth() != captureWidth) {
                Bitmap cropped = Bitmap.createBitmap(bitmap, 0, 0, captureWidth, captureHeight);
                bitmap.recycle();
                bitmap = cropped;
            }

            image.close();
            image = null;

            makePbufferCurrent();

            int outputTex = renderer.process(bitmap);
            bitmap.recycle();

            if (overlayOutputSurface != null && surfaceReady) {
                renderToOverlay(outputTex);
            }

            // FPS counting
            frameCount++;
            long now = System.currentTimeMillis();
            if (now - fpsStartTime >= 1000) {
                float fps = frameCount * 1000.0f / (now - fpsStartTime);
                frameCount = 0;
                fpsStartTime = now;

                Intent fpsIntent = new Intent("com.anime4k.screen.FPS_UPDATE");
                fpsIntent.putExtra("fps", fps);
                fpsIntent.setPackage(getPackageName());
                sendBroadcast(fpsIntent);
            }

        } catch (Exception e) {
            Log.e(TAG, "Error processing frame", e);
            if (image != null) {
                try { image.close(); } catch (Exception ex) {}
            }
        }

        if (isRunning) {
            processingHandler.post(this::processFrame);
        }
    }

    // ==================== EGL & Rendering ====================

    private void renderToOverlay(int texture) {
        try {
            if (eglOverlaySurface == null || eglOverlaySurface == EGL14.EGL_NO_SURFACE) {
                if (overlayOutputSurface != null) {
                    int[] surfaceAttribs = { EGL14.EGL_NONE };
                    eglOverlaySurface = EGL14.eglCreateWindowSurface(
                            eglDisplay, getEGLConfig(), overlayOutputSurface, surfaceAttribs, 0);
                }
            }

            if (eglOverlaySurface == null || eglOverlaySurface == EGL14.EGL_NO_SURFACE) {
                return;
            }

            EGL14.eglMakeCurrent(eglDisplay, eglOverlaySurface, eglOverlaySurface, eglContext);

            // Use current screen dimensions for rendering
            renderer.renderToScreen(texture, screenWidth, screenHeight);

            EGL14.eglSwapBuffers(eglDisplay, eglOverlaySurface);

            makePbufferCurrent();
        } catch (Exception e) {
            Log.e(TAG, "Error rendering to overlay", e);
            if (eglOverlaySurface != null && eglOverlaySurface != EGL14.EGL_NO_SURFACE) {
                EGL14.eglDestroySurface(eglDisplay, eglOverlaySurface);
                eglOverlaySurface = null;
            }
        }
    }

    private void initEGL() {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
        int[] version = new int[2];
        EGL14.eglInitialize(eglDisplay, version, 0, version, 1);

        EGLConfig config = getEGLConfig();

        int[] contextAttribs = {
            EGL14.EGL_CONTEXT_CLIENT_VERSION, 2,
            EGL14.EGL_NONE
        };
        eglContext = EGL14.eglCreateContext(eglDisplay, config,
                EGL14.EGL_NO_CONTEXT, contextAttribs, 0);

        int[] pbufferAttribs = {
            EGL14.EGL_WIDTH, 1,
            EGL14.EGL_HEIGHT, 1,
            EGL14.EGL_NONE
        };
        eglSurface = EGL14.eglCreatePbufferSurface(eglDisplay, config, pbufferAttribs, 0);

        makePbufferCurrent();
    }

    private void makePbufferCurrent() {
        EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext);
    }

    private EGLConfig getEGLConfig() {
        int[] configAttribs = {
            EGL14.EGL_RED_SIZE, 8,
            EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT | EGL14.EGL_PBUFFER_BIT,
            EGL14.EGL_NONE
        };
        EGLConfig[] configs = new EGLConfig[1];
        int[] numConfigs = new int[1];
        EGL14.eglChooseConfig(eglDisplay, configAttribs, 0, configs, 0, 1, numConfigs, 0);
        return configs[0];
    }

    private void releaseEGL() {
        if (eglDisplay != null) {
            if (eglOverlaySurface != null && eglOverlaySurface != EGL14.EGL_NO_SURFACE) {
                EGL14.eglDestroySurface(eglDisplay, eglOverlaySurface);
            }
            if (eglSurface != null && eglSurface != EGL14.EGL_NO_SURFACE) {
                EGL14.eglDestroySurface(eglDisplay, eglSurface);
            }
            if (eglContext != null && eglContext != EGL14.EGL_NO_CONTEXT) {
                EGL14.eglDestroyContext(eglDisplay, eglContext);
            }
            EGL14.eglTerminate(eglDisplay);
        }
    }

    // ==================== Notification ====================

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Anime4K Screen Service",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Anime4K 屏幕超分服务运行通知");
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private Notification createNotification() {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0,
                notificationIntent, PendingIntent.FLAG_IMMUTABLE);

        Intent stopIntent = new Intent(this, OverlayService.class);
        stopIntent.setAction("STOP");
        PendingIntent stopPendingIntent = PendingIntent.getService(this, 1,
                stopIntent, PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }

        return builder
                .setContentTitle("Anime4K 屏幕超分运行中")
                .setContentText("捕获: " + captureWidth + "x" + captureHeight +
                        " -> 输出: " + screenWidth + "x" + screenHeight)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(pendingIntent)
                .addAction(android.R.drawable.ic_media_pause, "停止", stopPendingIntent)
                .setOngoing(true)
                .build();
    }

    // ==================== Lifecycle ====================

    @Override
    public void onDestroy() {
        isRunning = false;

        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }

        if (mediaProjection != null) {
            mediaProjection.stop();
            mediaProjection = null;
        }

        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }

        if (processingHandler != null) {
            processingHandler.post(() -> {
                if (renderer != null) {
                    renderer.release();
                    renderer = null;
                }
                releaseEGL();
            });
        }

        // Remove floating button
        if (floatButton != null) {
            try {
                windowManager.removeView(floatButton);
            } catch (Exception e) {
                Log.e(TAG, "Error removing float button", e);
            }
            floatButton = null;
        }

        if (overlaySurfaceView != null) {
            try {
                windowManager.removeView(overlaySurfaceView);
            } catch (Exception e) {
                Log.e(TAG, "Error removing overlay", e);
            }
            overlaySurfaceView = null;
        }

        if (processingThread != null) {
            processingThread.quitSafely();
            processingThread = null;
        }

        // Unregister receivers and callbacks
        if (serviceReceiver != null) {
            try {
                unregisterReceiver(serviceReceiver);
            } catch (Exception e) {
                // ignore
            }
            serviceReceiver = null;
        }

        if (configCallback != null) {
            try {
                unregisterComponentCallbacks(configCallback);
            } catch (Exception e) {
                // ignore
            }
            configCallback = null;
        }

        // Notify activity
        Intent intent = new Intent("com.anime4k.screen.SERVICE_STOPPED");
        intent.setPackage(getPackageName());
        sendBroadcast(intent);

        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
