        GLES20.glDeleteTextures(2, new int[]{tempTex, tempTex2}, 0);

        // Unbind
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);

        return outputTexture;
    }

    public void renderToScreen(int texture, int screenWidth, int screenHeight) {
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);
        GLES20.glViewport(0, 0, screenWidth, screenHeight);
        GLES20.glClearColor(0, 0, 0, 1);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
        // Use flipped vertex buffer for screen output to correct Y-axis orientation
        drawQuadWithBuffer(programPassthrough, new int[]{texture}, new String[]{"uTexture"}, vertexBufferFlipped);
    }

    private void drawQuad(int program, int[] textures, String[] uniformNames) {
        drawQuadWithBuffer(program, textures, uniformNames, vertexBuffer);
    }

    private void drawQuadWithBuffer(int program, int[] textures, String[] uniformNames, FloatBuffer vbuf) {
        GLES20.glUseProgram(program);

        int posLoc = GLES20.glGetAttribLocation(program, "aPosition");
        int texLoc = GLES20.glGetAttribLocation(program, "aTexCoord");

        vbuf.position(0);
        GLES20.glEnableVertexAttribArray(posLoc);
        GLES20.glVertexAttribPointer(posLoc, 2, GLES20.GL_FLOAT, false, 16, vbuf);

        vbuf.position(2);
        GLES20.glEnableVertexAttribArray(texLoc);
        GLES20.glVertexAttribPointer(texLoc, 2, GLES20.GL_FLOAT, false, 16, vbuf);

        for (int i = 0; i < textures.length; i++) {
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0 + i);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textures[i]);
            int uLoc = GLES20.glGetUniformLocation(program, uniformNames[i]);
            GLES20.glUniform1i(uLoc, i);
        }

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);

        GLES20.glDisableVertexAttribArray(posLoc);
        GLES20.glDisableVertexAttribArray(texLoc);
    }

    private void setTexelSize(int program, int w, int h) {
        int loc = GLES20.glGetUniformLocation(program, "uTexelSize");