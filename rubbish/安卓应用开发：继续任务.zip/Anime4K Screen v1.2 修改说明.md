# Anime4K Screen v1.2 修改说明

## 版本信息

- **版本号**: v1.2 (versionCode: 3)
- **包名**: com.anime4k.screen
- **最低 SDK**: Android 8.0 (API 26)
- **目标 SDK**: Android 13 (API 33)

---

## 修改内容概述

本次更新包含三项主要功能改进和两项 Bug 修复。

---

## 1. 悬浮控制按钮

### 功能说明

在屏幕叠加层上方添加了一个 48dp 的圆形悬浮按钮，用于快速控制超分效果。

### 交互方式

| 操作 | 功能 |
|------|------|
| **单击** | 暂停/恢复超分处理（暂停时叠加层隐藏，显示原始画面） |
| **拖动** | 将按钮移动到屏幕任意位置 |
| **松手** | 自动吸附到屏幕左右边缘 |
| **长按** | 弹出菜单（停止服务 / 返回主界面） |

### 视觉状态

- **超分开启时**: 青色背景 (#03DAC5)，显示暂停图标（表示点击可暂停）
- **超分暂停时**: 灰色背景 (#888888)，显示播放图标（表示点击可恢复）
- **整体透明度**: 0.8f，不过度遮挡屏幕内容

### 技术实现

- 使用独立的 `WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY` 窗口
- 设置 `FLAG_NOT_FOCUSABLE` 但保留触摸响应
- 通过 `OnTouchListener` 实现拖动、单击和长按的区分
- 长按阈值 600ms，拖动阈值 10px
- 暂停时通过 `overlaySurfaceView.setVisibility(View.GONE)` 隐藏叠加层
- 恢复时通过 `overlaySurfaceView.setVisibility(View.VISIBLE)` 显示叠加层

---

## 2. 叠加层透明度控制

### 功能说明

在主界面设置卡片中新增「叠加层透明度」SeekBar，可实时调整超分叠加层的透明度。

### 参数

| 属性 | 值 |
|------|------|
| **范围** | 0 - 100 |
| **默认值** | 100（完全不透明） |
| **对应 alpha** | 0.0 - 1.0 |
| **持久化** | SharedPreferences ("opacity") |

### 实时调整

当服务正在运行时，调整 SeekBar 会立即通过广播 (`com.anime4k.screen.UPDATE_OPACITY`) 将新的透明度值发送给 `OverlayService`，服务端通过 `WindowManager.LayoutParams.alpha` 实时更新叠加层透明度。

---

## 3. 取消帧率限制

### 修改说明

移除了原有的帧间隔 (`frameInterval`) 设置和 `postDelayed` 调度机制，改为连续处理模式。

### 技术细节

- **移除**: `scheduleNextFrame()` 中的 `postDelayed(this::processFrame, frameInterval)`
- **改为**: 处理完一帧后立即 `processingHandler.post(this::processFrame)` 处理下一帧
- **ImageReader maxImages**: 从 2 增加到 4，配合 `acquireLatestImage()` 丢弃旧帧
- **暂停机制**: 暂停时以 100ms 间隔轮询，恢复后立即进入连续处理

### 保留功能

- FPS 显示功能完整保留，每秒通过广播更新
- `acquireLatestImage()` 确保始终处理最新帧，避免积压

---

## Bug 修复

### 修复画面上下颠倒

**原因**: OpenGL ES 的 Y 轴方向（从下到上）与 Android 屏幕的 Y 轴方向（从上到下）相反。原始代码在渲染到屏幕时使用了与 FBO 渲染相同的纹理坐标，导致最终输出画面上下颠倒。

**修复方案**: 在 `Anime4KRenderer` 中新增 Y 轴翻转的顶点缓冲 (`QUAD_VERTICES_FLIPPED`)，将纹理坐标的 V 分量翻转（0 变 1，1 变 0）。`renderToScreen()` 方法使用翻转缓冲，而 FBO 内部的 pass 仍使用原始缓冲。

### 修复按悬浮按钮后叠加层不消失

**原因**: 原始的 `togglePause()` 方法仅设置了 `isPaused` 标志位并停止处理新帧，但叠加层 SurfaceView 仍然显示最后一帧的内容，覆盖在屏幕上方。

**修复方案**: 暂停时调用 `overlaySurfaceView.setVisibility(View.GONE)` 隐藏叠加层，恢复时调用 `setVisibility(View.VISIBLE)` 重新显示。同时修正了按钮图标逻辑：活跃时显示暂停图标，暂停时显示播放图标。

---

## 修改的文件清单

| 文件 | 修改内容 |
|------|----------|
| `Anime4KRenderer.java` | 添加 Y 翻转顶点缓冲，修复画面颠倒；重构 drawQuad 为 drawQuadWithBuffer |
| `OverlayService.java` | 添加悬浮按钮、透明度接收器、连续帧处理；暂停时隐藏叠加层 |
| `MainActivity.java` | 移除帧间隔 UI，添加透明度 SeekBar 和广播发送逻辑 |
| `activity_main.xml` | 移除帧间隔 SeekBar，添加透明度 SeekBar |
| `strings.xml` | 添加透明度和悬浮按钮相关字符串资源 |
| `app/build.gradle` | 版本号更新为 v1.2，添加 cardview 依赖 |

---

## 使用方法

1. 安装 `Anime4KScreen-v1.2-debug.apk`
2. 打开应用，调整捕获缩放比例、超分强度和叠加层透明度
3. 点击「启动超分」，授予屏幕录制和悬浮窗权限
4. 应用将最小化，屏幕上显示超分后的画面和悬浮控制按钮
5. 单击悬浮按钮可快速暂停/恢复超分效果（暂停时叠加层隐藏）
6. 长按悬浮按钮可选择停止服务或返回主界面
7. 也可通过通知栏停止服务

---

## 性能说明

取消帧率限制后，应用将以设备 GPU 能力允许的最大速度处理帧。实际 FPS 取决于设备性能和捕获分辨率设置。建议根据设备性能适当调整捕获缩放比例以获得最佳体验。
